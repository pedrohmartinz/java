/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package aulas;

import java.io.File;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;

/**
 *
 * @author Thiago
 */
public class TocadorSom {
    
        String  path;


    public void tocaSom(String strCaractere){
   
       
             try{
                Clip clip = AudioSystem.getClip();
                clip.open(AudioSystem.getAudioInputStream(new File(strCaractere)));
                clip.start();
             
             }catch (Exception exc){
                exc.printStackTrace(System.out);
             }
             
   
    }
}
