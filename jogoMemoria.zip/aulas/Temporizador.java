/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package aulas;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Thiago
 */
public class Temporizador implements ActionListener {
    
    int status =0;
    
    
    
    @Override
    public void actionPerformed(ActionEvent e) {

    }
    
    public int mudaStatus(){
        return 3;
    }


}




